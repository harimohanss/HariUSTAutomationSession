package com.example.demo_ticket.exception;

public class InvalidPlaceNameException extends RuntimeException{
	public InvalidPlaceNameException(String message) {
		super(message);
	}
}
