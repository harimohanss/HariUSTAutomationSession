package com.example.demo_resttemplate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoResttemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoResttemplateApplication.class, args);
	}

}
